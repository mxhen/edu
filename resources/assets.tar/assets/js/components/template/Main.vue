<template>
<div class="edu-flex">
</div>
</template>
<script>
	module.exports= {
		data:function(){
			
		},
		methods:{
		}
    }
</script>
<style scoped>
	.edu-flex{
		display:flex;
		flex:1 0 auto;
		flex-direction:column;
		justify-content:flex-start;
		align-items:center;
	}
</style>
