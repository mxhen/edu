<template>
	<div class="edu-flex">
		<div>
			<span>CopyRight@2018 XXXX公司  闽ICP备B2-20050028号</span>
			<a href="https://lililala.cc/lila">技术支持:哩啦</a>
		</div>
		<div>
			<span>全国免费服务电话:010-00000000</span>
		</div>
	</div>
</template>
<style scoped>
	.edu-flex{
		display:flex;
		flex-direction:row;
		justify-content:space-between;
		align-items:center;
		padding-left:20%;
		padding-right:20%;
		height:35px;
		background-color:#202020;
		color:#888888;
		flex:0 0 auto;
	}
	.edu-flex a{
		text-decoration:none;
		color:#888888;
		margin-left:10px;
		margin-right:10px;
	}
	.edu-flex a:hover{
		color:white;
	}
</style>
