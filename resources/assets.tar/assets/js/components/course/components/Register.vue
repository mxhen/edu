<template>
<div class="edu-register">
    <input placeholder="用户名"/>
    <input placeholder="邮箱"/>
    <input placeholder="密码" type="password"/>
    <input placeholder="确认密码" type="password"/>
    <div>
        <button>提交</button>
    </div>
</div>
</template>
