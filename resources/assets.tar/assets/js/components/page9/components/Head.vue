<template>
	<div class="flex-row head">
		<div class="flex-row">
			<span>用户名</span>
			<span>消息</span>
		</div>
		<div class="flex-row">
			<a>文化基因在线首页</a>
			<span>我的基因库</span>
			<span>收藏夹</span>
			<span>购物车</span>
			<span>登陆</span>
		</div>
	</div>
	<div class="flex-row head">
		<a href="index.html"></a>
		<span>走进新大陆</span>
		<span>发展历程</span>
		<span>荣誉资质</span>
		<span>合作与商机</span>
		<span>科技竞赛</span>
	</div>
</template>
<style scoped>
	.flex-row{
		display:flex;
		flex-direction:row;
		justify-content:flex-start;
		align-items:center;
	}
	.head{
		width:100%;
		height:60px;
		justify-content:space-between!important;
		background-color:#C9C9C9;
	}
</style>
