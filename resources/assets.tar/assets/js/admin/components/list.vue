<template>
<div class="head">
    <div class="news-detail">
        <div class="news-title">
            <span style="font-size:20px">科技创新</span>
        </div>
        <div class="second-title">
            <p>2017-12-05 胡钢董事长当选为中华全国工商联第十二届执行委员会常务委员</p>
            <p>2017-12-05 胡钢董事长当选为中华全国工商联第十二届执行委员会常务委员</p>
            <p>2017-12-05 胡钢董事长当选为中华全国工商联第十二届执行委员会常务委员</p>
            <p>2017-12-05 胡钢董事长当选为中华全国工商联第十二届执行委员会常务委员</p>
            <p>2017-12-05 胡钢董事长当选为中华全国工商联第十二届执行委员会常务委员</p>
            <p>2017-12-05 胡钢董事长当选为中华全国工商联第十二届执行委员会常务委员</p>
            <p>2017-12-05 胡钢董事长当选为中华全国工商联第十二届执行委员会常务委员</p>
            <p>2017-12-05 胡钢董事长当选为中华全国工商联第十二届执行委员会常务委员</p>
        </div>
        <div class="third-title">
            <span>首页</span><span>下一页</span><span>末页</span>
        </div>
    </div>
</div>
</template>
<style scoped>
@import './list.css'
</style>
