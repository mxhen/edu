<template>
<div class="head">
    <div class="news-detail">
        <div class="news-title">
            <span style="font-size:20px">胡钢董事长当选为中华全国工商联第十二届执行委员会常务委员</span>
        </div>
        <div class="second-title">
            <span>发布日期:2017-3-4</span>
            <span>浏览次数:89</span>
        </div>
        <div class="third-title">
            中国工商业联合会第十二次全国代表大会日前在北京召开，会议选举产生中华全国工商联新一届执行委员会，高云龙为十二届全国工商联执行委员会主席，徐乐江为常务副主席，胡钢董事长当选常务委员。
            <br />
            <br />
            <img src="/timg.jpg"/>
            据了解，中华全国工商联成立于1953年，是中国爱国统一战线的组成部分，中国人民政治协商会议的组成单位之一，具有统战性、民间性和经济性统一的特点，是一支为社会主义服务的政治力量。
        </div>
    </div>
</div>
</template>
<style scoped>
@import './detail.css'
</style>
